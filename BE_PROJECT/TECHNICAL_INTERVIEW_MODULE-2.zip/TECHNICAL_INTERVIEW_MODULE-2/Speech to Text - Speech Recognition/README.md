# Speech to Text - Speech Recognition

**Complete Video Tutorial:** https://youtu.be/U4nEKYDT9-I

## Project Information

The objective of the project is to convert speech to text in real time and convert audio file to text. It uses google speech api to convert the audio to text.

## Install Modules
> pip install speechrecognition
> conda install pyaudio


## Libraries

- speech_recognition
- google speech api