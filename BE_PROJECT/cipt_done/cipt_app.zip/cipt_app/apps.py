from django.apps import AppConfig


class CiptAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cipt_app'
