from django.apps import AppConfig


class SecondPhaseConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'second_phase'
