from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.empty import EmptyOperator
from datetime import datetime, timedelta

# Define a default argument for the Dataflow template
default_args = {
    "owner": "airflow",
    "start_date": datetime(2021, 1, 1),
}

# Create a DAG
dag = DAG(      
    "shabaz_basic_Check",
    default_args=default_args,
    schedule_interval=None,
)

# Define the DummyOperator
start_task = EmptyOperator(
    task_id='start_task',
    dag=dag
)


end_task = EmptyOperator(
    task_id='end_task',
    dag=dag
)

start_task >> end_task