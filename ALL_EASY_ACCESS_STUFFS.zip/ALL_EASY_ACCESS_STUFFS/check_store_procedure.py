from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.empty import EmptyOperator
from airflow.providers.google.cloud.transfers.gcs_to_bigquery import GCSToBigQueryOperator
from airflow.providers.google.cloud.transfers.bigquery_to_bigquery import BigQueryToBigQueryOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryExecuteQueryOperator
from airflow.utils.dates import days_ago
from datetime import datetime, timedelta


default_args = {
    'owner' : "Shabaz",
    "retries" : 0,
    "retry_delay" : timedelta(minutes=5),
}


def timestamp(**kwargs):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    kwargs['ti'].xcom_push(key='timestamp', value=ts)


with DAG(
    dag_id = "A_STORE_PROCEDURE_CHECK",
    default_args = default_args,
    description = "airflow assignment dag",
    start_date = datetime(2023,2,14), 
) as dag:

    #Task_01: Use Python Operator to set the current timestamp in XCOM 
    task1 = PythonOperator(
        task_id = "timestamp_from_xcom",
        python_callable=timestamp,
        dag = dag,
    )

    #Task_2b: Use BigQueryExecuteQueryOperator to call the stored procedure that updates the table with the timestamp
    task2b = BigQueryExecuteQueryOperator(
    task_id='bq_execute_stored_procedure_task2b',
    sql='CALL anshul_shabaz_composer.update_table_with_timestamp_v3()',
    use_legacy_sql=False,
    params={"timestamp": "{{ ti.xcom_pull(task_ids='timestamp_from_xcom') }}"},
    dag=dag,
    )


    #Task_3b: Move data to other tables using the BQtoBQ operator from task2b table.
    task3b = BigQueryToBigQueryOperator(
        task_id = 'bq_to_bq_task3b',
        source_project_dataset_tables = 'amazonreviewproject:anshul_shabaz_composer.csv_to_bq_with_timstamp_addon',
        destination_project_dataset_table = 'amazonreviewproject:anshul_shabaz_composer.bq_to_bq_task2b_addon',
        create_disposition = 'CREATE_IF_NEEDED',
        write_disposition = 'WRITE_APPEND',
        dag = dag,
    )

    #Task_4: End Task using DummyOperator
    task4 = EmptyOperator(
        task_id = "Dummy_operator_task4",
        dag = dag,
    )

task1 >> task2b >> task3b >> task4
