from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.empty import EmptyOperator
from airflow.providers.google.cloud.operators.dataflow import DataflowTemplatedJobStartOperator
from airflow.providers.google.cloud.transfers.gcs_to_bigquery import GCSToBigQueryOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryExecuteQueryOperator
from airflow.providers.google.cloud.transfers.bigquery_to_bigquery import BigQueryToBigQueryOperator
from airflow.utils.dates import days_ago

 
default_args = {
    'owner' : "Shabaz",
    "retries" : 0,
    "retry_delay" : timedelta(minutes=300),
}
 

def timestamp(**kwargs):
    """
    The timestamp function generates a timestamp and pushes it to Airflow's XCom service. 
    The timestamp is in the format "YYYY-MM-DD HH:MM:SS".

    Parameters:
        **kwargs: A dictionary containing task instance information. 
        This parameter is required by Airflow to execute the task.

    Returns: None.

    XCom Pushed:
        timestamp: The current timestamp in the format "YYYY-MM-DD HH:MM:SS".
    """
    timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    kwargs["ti"].xcom_push(key='timestamp', value=timestamp)

 
with DAG(
    dag_id = "all_combine_task_for_airflow_operator_assignment_addon_v2",
    default_args = default_args,
    description = "airflow assignment dag",
    start_date = datetime(2021,2,14), 
) as dag:

    #Task_01: Use Python Operator to set the current timestamp in XCOM 
    task1 = PythonOperator(
        task_id = "timestamp_from_xcom",
        python_callable=timestamp,
        dag = dag,
    )
 
    #Task_2a: Use Dataflow Template Operator, to write CSV from GCS to BQ (table name: anshul_{yourname}.csv_to_bq_with_timstamp), Use ingestion timestamp from XCOM. 
    task2a = DataflowTemplatedJobStartOperator(
        task_id = "gcs_to_bq_with_timestamp_task2a",
        job_name='dataflowjobgcstobqeithtime',
        template = "gs://for_all_anshuls_task/Shabaz/Dataflow/Batch/templates/empwithtimestampxcom",
        parameters = {'timestamp': '{{ task_instance.xcom_pull(task_ids="timestamp_from_xcom", key="timestamp") }}'},
        dataflow_default_options = {'project': 'amazonreviewproject','save_main_session': "True"},
        dag = dag,
    )
    
    #Task_2b: Use GCS to BQ operator to keep CSV content in BigQuery in the table(table name: anshul_{yourname}.csv_to_bq_without_timstamp). 
    task2b = GCSToBigQueryOperator(
        task_id = 'gcs_to_bq_without_timestamp_task2b',
        bucket = 'for_all_anshuls_task',
        source_objects = ['Shabaz/Dataflow/Batch/employee.csv'],
        destination_project_dataset_table = 'amazonreviewproject.anshul_shabaz_composer.csv_to_bq_with_timstamp_addon',
        schema_fields = [
            {'name': 'id', 'type': 'INTEGER', 'mode': 'NULLABLE'},
            {'name': 'name', 'type': 'STRING', 'mode': 'NULLABLE'},
            {'name': 'email', 'type': 'STRING', 'mode': 'NULLABLE'},
        ],
        create_disposition = 'CREATE_IF_NEEDED',
        write_disposition = 'WRITE_APPEND',
        dag = dag,
    )
    #Task_2c: Use BigQueryExecuteQueryOperator to call the stored procedure that updates the table with the timestamp
    task2c = BigQueryExecuteQueryOperator(
    task_id='bq_execute_stored_procedure_task2b',
    sql='CALL anshul_shabaz_composer.update_table_with_timestamp_v3()',
    use_legacy_sql=False,
    params={"timestamp": "{{ ti.xcom_pull(task_ids='timestamp_from_xcom') }}"},
    dag=dag,
    )

    #Task_3a: Move data to other tables using the BQtoBQ operator from task2a table.
    task3a = BigQueryToBigQueryOperator(
        task_id = 'bq_to_bq_task3a',
        source_project_dataset_tables = 'amazonreviewproject:anshul_shabaz_composer.csv_to_bq_with_timstamp',
        destination_project_dataset_table = 'amazonreviewproject:anshul_shabaz_composer.bq_to_bq_task2a',
        create_disposition = 'CREATE_IF_NEEDED',
        write_disposition = 'WRITE_APPEND',
        dag = dag,
    )

    #Task_3b: Move data to other tables using the BQtoBQ operator from task2b table.
    task3b = BigQueryToBigQueryOperator(
        task_id = 'bq_to_bq_task3b',
        source_project_dataset_tables = 'amazonreviewproject:anshul_shabaz_composer.csv_to_bq_with_timstamp_addon',
        destination_project_dataset_table = 'amazonreviewproject:anshul_shabaz_composer.bq_to_bq_task2b_addon',
        create_disposition = 'CREATE_IF_NEEDED',
        write_disposition = 'WRITE_APPEND',
        dag = dag,
    )
 
    #Task_4: End Task using DummyOperator
    task4 = EmptyOperator(
        task_id = "Dummy_operator_task4",
        dag = dag,
    )
	
    
task1 >> [task2a, task2b]
task2a >> task3a >> task4
task2b >> task2c >> task3b >> task4

# task1.set_downstream([task2a, task2b])
# task2a.set_downstream(task3a)
# task2b.set_downstream(task3b)
# [task3a, task3b].set_downstream(task4)