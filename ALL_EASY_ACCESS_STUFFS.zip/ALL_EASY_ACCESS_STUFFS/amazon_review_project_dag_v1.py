from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.empty import EmptyOperator
from airflow.providers.google.cloud.operators.dataflow import DataflowTemplatedJobStartOperator
from airflow.utils.dates import days_ago
from datetime import datetime, timedelta
from airflow.providers.google.cloud.operators.bigquery import BigQueryCreateEmptyTableOperator
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from google.cloud import bigquery
 
default_args={
    "start_date": days_ago(1),
    "retries" : 0,
    "retry_delay" : timedelta(minutes = 5),
    "gcp_conn_id" : "arp"
}


def timestamp(**kwargs):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    kwargs["ti"].xcom_push(key = 'timestamp', value = timestamp)


def insert_metadata_row(**kwargs):
    # get metadata table ID from Airflow variable
    metadata_table = "{{ var.value.metadata_table }}"
    
    # get job ID and status from Dataflow job
    job_id = kwargs["ti"].xcom_pull(task_ids="csv_amazon_review_product_prediction_to_bq", key="job_id")
    status = kwargs["ti"].xcom_pull(task_ids="csv_amazon_review_product_prediction_to_bq", key="status")
    
    # get start and end times
    start_time = kwargs["ti"].xcom_pull(task_ids="csv_amazon_review_product_prediction_to_bq", key="start_time")
    end_time = datetime.utcnow()

    # construct SQL query to insert row into metadata table
    sql = f"""
        INSERT INTO `{metadata_table}`
        (job_id, start_time, end_time, status)
        VALUES ('{job_id}', '{start_time}', '{end_time}', '{status}')
        """
    # create BigQuery hook and execute SQL query
    bq_hook = BigQueryHook(gcp_conn_id='arp')
    bq_conn = bq_hook.get_conn()
    cursor = bq_conn.cursor()
    cursor.execute(sql)
    bq_conn.commit()


with DAG(
    "amazon_review_project",
    description="For daily reviews check",
    default_args = default_args,
    start_date = datetime(2023,2,14), 
    # schedule_interval = '@daily'
) as dag:

    #task1
    t1 = EmptyOperator(
        task_id = "Start",
        dag = dag,
    )

    # task to run data processing job and insert row into metadata table
    t2 = DataflowTemplatedJobStartOperator(
        task_id="csv_amazon_review_product_prediction_to_bq",
        template="gs://amazon_review_project_main/dataflow/templates/finalpredictiontemplatefordag",
        job_name="csv_amazon_review_product_prediction_to_bq",
        on_success_callback=insert_metadata_row,
        dataflow_default_options={
            "project": "amazon-reviews-377910",'save_main_session': "True"
        },
        dag=dag,
    )


    # Define the schema for the metadata table
    SCHEMA = [
        {"name": "job_id", "type": "STRING", "mode": "REQUIRED"},    
        {"name": "start_time", "type": "TIMESTAMP", "mode": "REQUIRED"},    
        {"name": "end_time", "type": "TIMESTAMP", "mode": "REQUIRED"},    
        {"name": "status", "type": "STRING", "mode": "REQUIRED"},    
        {"name": "message", "type": "STRING", "mode": "NULLABLE"},
            ]


    
    # Task to create metadata table
    t3 = BigQueryCreateEmptyTableOperator(
        task_id="create_metadata_table",
        project_id="amazon-reviews-377910",
        dataset_id="Adding_Metadata_for_Amazon_Reviews_Project",
        table_id="metadata_table",
        schema_fields=SCHEMA,
        location="us-east1",
        bigquery_conn_id="arp", # replace with your BigQuery connection ID
        dag=dag,
    )

    #task4
    t4 = EmptyOperator(
        task_id = "End",
        dag = dag,
    )

   
t1 >> t2 >> t3 >> t4