Threading
---------

**Create A Progress Bar for Downloads** - Create a progress bar for applications that can keep track of a download in progress. The progress bar will be on a separate thread and will communicate with the main thread using delegates.

**Download Manager** - Allow your program to download various files and each one is downloading in the background on a separate thread. The main thread will keep track of the other thread's progress and notify the user when downloads are completed.

**Chat Application (remoting style)** - Create a chat application which allows you to connect directly to another computer by their IP through the use of remoting and allow your "server" application handle multiple incoming connections.

**Bulk Thumbnail Creator** - Picture processing can take a bit of time for some transformations. Especially if the image is large. Create an image program which can take hundreds of images and converts them to a specified size in the background thread while you do other things. For added complexity, have one thread handling re-sizing, have another bulk renaming of thumbnails etc.

