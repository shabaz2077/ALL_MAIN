# Calculate the number of seconds in a year

print "There are", 60 * 60 * 24 * 365, "seconds in a year"
