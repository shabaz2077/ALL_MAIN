# Print statement
print "I will now count my chickens:"

# Print "Hens" followed by calculation of 25+(30/6)
print "Hens", 25 + 30 / 6

# Print "Roosters" followed by calculation of 100-((25*3)%4)
print "Roosters", 100 - 25 * 3 % 4

# Print statement
print "Now I will count the eggs:"

# Calculate 3+2+1-5+(4%2)-(1/4)+6 (no floating-point math)
# Rewrote to include floating-point math
print 3 + 2 + 1 - 5 + 4 % 2 - 0.25 + 6

# Print statement
print "Is it true that 3 + 2 < 5 - 7?"

# Print the boolean test result of "is 3+2 less than 5-7?"
print 3 + 2 < 5 - 7

# Print the question "What is 3+2?" followed by the result of 3+2
print "What is 3 + 2?", 3 + 2

# Print the question "What is 5-7?" followed by the result of 5-7
print "What is 5 - 7?", 5 - 7

# Print statement
print "Oh, that's why it's False."

# Print statement
print "How about some more."

# Print the question "Is it greater?" followed by the boolean test result of "is 5 greater than -2?"
print "Is it greater?", 5 > -2

# Print the question "Is it greater or equal?" followed by the boolean test result of "is 5 greater than or equal to -2?"
print "Is it greater or equal?", 5 >= -2

# Print the question "Is it less or equal?" followed by the boolean test results of "is 5 less than or equal to -2?"
print "Is it less or equal?", 5 <= -2
