print(sum([int(i) for i in str(2**1000)]))
