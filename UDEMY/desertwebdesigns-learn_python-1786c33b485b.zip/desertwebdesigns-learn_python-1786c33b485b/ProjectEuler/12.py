def is_prime(n):
    if n % 2 == 0 and n != 2:
        return False

    for i in range(3, int(n**0.5) + 1, 2):
        if n % i == 0:
            return False
    return True


def divisor_count(n):
    factors = []
    divisors = 1
    while n != 1:
        for i in range(2,n+1):
            if n%i == 0 and is_prime(i):
                factors.append(i)
                n = int(n/i)
                break
    for i in set(factors):
        divisors *= (factors.count(i)+1)

    return divisors

n = t = 0
while True:
    n+=1
    t = sum([i for i in range(1,n+1)])

    if divisor_count(t) > 500:
        break

print("{} Triangle Number {} has {} divisors".format(n,t,divisor_count(t)))
