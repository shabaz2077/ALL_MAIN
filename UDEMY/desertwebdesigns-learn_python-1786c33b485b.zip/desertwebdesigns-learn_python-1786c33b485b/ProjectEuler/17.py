import inflect

total_str = ''

p = inflect.engine()

for i in range(1,1001):
    total_str += p.number_to_words(i).replace('-', '').replace(' ','')

print(len(total_str))
