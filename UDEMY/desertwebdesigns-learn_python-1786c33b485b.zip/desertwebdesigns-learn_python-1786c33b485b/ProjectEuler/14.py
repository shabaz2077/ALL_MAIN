max_seq = []
start_num = 0

for i in range(1,1000000):
    number = i
    seq = []

    while number > 1:
        if (number % 2 == 0):
            number /= 2
        else:
            number = (number * 3) + 1

        seq.append(number)

    if len(seq) > len(max_seq):
        max_seq = seq
        start_num = i

print("Starting number: {}\nSequence Length: {}".format(start_num, max_seq))
