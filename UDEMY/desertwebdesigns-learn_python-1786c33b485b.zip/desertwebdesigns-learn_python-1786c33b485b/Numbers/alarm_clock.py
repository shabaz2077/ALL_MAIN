"""A simple clock where it plays a sound after X number of minutes/seconds or
at a particular time."""

import datetime as dt
import time

def alarm_start():
    pass

def alarm_set(set_time):
    s = dt.datetime.strptime(set_time, '%H:%M:%S').time()
    set_time = dt.timedelta(
        hours = s.hour,
        minutes = s.minute,
        seconds = s.second
    )

    t = dt.datetime.now().time()
    cur_time = dt.timedelta(
        hours = t.hour,
        minutes = t.minute,
        seconds = t.second
    )

    if cur_time > set_time:
        set_time = set_time + dt.timedelta(hours=24)

    d = set_time - cur_time
    run_timer(int(d.total_seconds()))

def timer_set(set_time):
    s = dt.datetime.strptime(set_time, '%H:%M:%S').time()
    set_time = dt.timedelta(
        hours = s.hour,
        minutes = s.minute,
        seconds = s.second
    )

    run_timer(int(set_time.total_seconds()))

def run_timer(seconds):
    while seconds:
        mins, secs = divmod(seconds, 60)
        timeformat = '{:02d}:{:02d}'.format(mins, secs)
        print(timeformat, end='\r')
        time.sleep(1)
        seconds -= 1

    print("Time's up!")

def main():
    choice = int(input("""\n1: Set Timer
2. Set Alarm

Choose clock type: """))

    if choice == 1:
        set_time = input("Timer length (HH:MM:SS): ")
        timer_set(set_time)
    elif choice== 2:
        set_time = input("Alarm time (HH:MM:SS): ")
        alarm_set(set_time)
    else:
        print("Invalid choice")
        exit()

if __name__ == "__main__":
    main()
